package deepthinking.service;
//package deepthinking.service;
//
//import java.lang.reflect.InvocationTargetException;
//import java.util.List;
//import java.util.Map;
//
//import deepthinking.crswi.inspection.domain.TCszdZdqz;
//import deepthinking.crswi.inspection.model.DictionaryModel;
//
//public interface QBSourceService extends BaseService<TCszdZdqz,Long>{
//	public Map<String, Map<Long, DictionaryModel>> getAllDics() 
//    		throws IllegalAccessException, InvocationTargetException, NoSuchMethodException;
//}
//
