package deepthinking.service.impl;
///********************************************
// * 服务接口的实现
// *
// * @author lvjianguo
// * @create 2018-08-10
// *********************************************/
//
//package deepthinking.service.impl;
//
//import deepthinking.service.BaseDataService;
//
//@Service("qBSourceService")
//public class QBSourceServiceImpl extends BaseServiceImpl<TCszdZdqz,Long> implements QBSourceService{
//
//}
