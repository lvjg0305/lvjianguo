/********************************************
 * 系统所有的数据总线
 *
 * @author zwq
 * @create 2018-06-03 20:08
 *********************************************/

package deepthinking.common;

public class DataBus {
  
}
