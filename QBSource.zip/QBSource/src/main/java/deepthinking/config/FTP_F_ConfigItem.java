package deepthinking.config;

public class FTP_F_ConfigItem {

    /**
     * 本地根目录
     */
    private String dirRoot;
    /**
     *文件类型
     */
    private String type;

    public String getDirRoot() {
        return dirRoot;
    }

    public void setDirRoot(String dirRoot) {
        this.dirRoot = dirRoot;
    }


    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
}
